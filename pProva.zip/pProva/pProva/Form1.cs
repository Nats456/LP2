﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pProva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
                double[,] notebooks = new double[5, 3];
                string aux1 = "";
                string resultado = "";
                double soma;
                double media;
                double mediat = 0;
                int n = 0;


                for (var i = 0; i < 3; i++)
                {
                    for (var j = 0; j < 5; j++)
                    {
                        aux1 = Interaction.InputBox($"Digite o valor do notebook {j + 1} na loja: {i + 1}");
                        if (!double.TryParse(aux1, out notebooks[j, i]))
                        {
                            MessageBox.Show("Número Inválido");
                            j--;
                        }
                    }
                }


                for (var j = 0; j < 5; j++)
                {
                    media = 0;
                    soma = 0;
                    for (var i = 0; i < 3; i++)
                    {
                        soma += notebooks[j, i];
                    }

                    media = soma / 3;
                    mediat += media/5;
                n++;
                resultado += $"notebook: {j + 1} loja {1}:{notebooks[0,1]} loja {2}: loja {3}: média de preço: {media.ToString("N2")}\n";
                }
                MessageBox.Show(resultado);
                MessageBox.Show("A média geral dos computadores foi: " + mediat.ToString("F"));

            }

        private void LstbDados_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

