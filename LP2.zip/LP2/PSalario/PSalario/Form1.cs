﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    
    public partial class Form1 : Form
    {
        double SalBruto, Filhos, DescINSS, DescIRPF, SalFam, SalaLiqui;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAliINSS.Text = string.Empty;
            mskbxDescINSS.Text = string.Empty;
            mskbxDescIRPF.Text = string.Empty;
            mskbxFilhos.Text = string.Empty;
            mskbxNome.Text = string.Empty;
            mskbxSalBruto.Text = string.Empty;
            mskbxSalFam.Text = string.Empty;
            mskbxAliIRPF.Text = string.Empty;
            mskbxNome.Focus();
        }

        private void BtnDesconto_Click(object sender, EventArgs e)
        {
            Filhos = Convert.ToDouble(mskbxFilhos.Value);
            if (SalBruto <= 435.52)
            {   
                SalFam = 22.33 * Filhos;
                mskbxSalFam.Text = SalFam.ToString("N2");
                mskbxAliINSS.Text = "7.65%";
                DescINSS = SalBruto * 0.0765;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("Isento");
                mskbxDescIRPF.Text = ("Isento");
                SalaLiqui = (SalBruto + SalFam) - DescINSS;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto <= 654.61)
            {
                SalFam = 15.74 * Filhos;
                mskbxSalFam.Text = SalFam.ToString("N2");
                mskbxAliINSS.Text = "7.65%";
                DescINSS = SalBruto * 0.0765;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("Isento");
                mskbxDescIRPF.Text = ("Isento");
                SalaLiqui = (SalBruto + SalFam) - DescINSS;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto < 800.47) {
                mskbxAliINSS.Text = "7.65%";
                DescINSS = SalBruto * 0.0765;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("Isento");
                mskbxDescIRPF.Text = ("Isento");                
                mskbxSalFam.Text = ("Não se Aplica");
                SalaLiqui = SalBruto - DescINSS;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto <= 1050)
            {
                mskbxAliINSS.Text = "8.65%";
                DescINSS = SalBruto * 0.0865;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("Isento");
                mskbxDescIRPF.Text = ("Isento");
                mskbxSalFam.Text = ("Não se Aplica");
                SalaLiqui = SalBruto - DescINSS;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto <= 1400.77)
            {
                mskbxAliINSS.Text = "9.00%";
                DescINSS = SalBruto * 0.0900;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("15.00%");
                DescIRPF = SalBruto * 0.15;
                mskbxDescIRPF.Text = DescIRPF.ToString("N2");
                mskbxSalFam.Text = ("Não se Aplica");
                SalaLiqui = SalBruto - DescINSS - DescIRPF;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto <= 2512.08)
            {
                mskbxAliINSS.Text = "11.00%";
                DescINSS = SalBruto * 0.11;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("15.00");
                DescIRPF = SalBruto * 0.15;
                mskbxDescIRPF.Text = DescIRPF.ToString("N2");
                mskbxSalFam.Text = ("Não se Aplica");
                SalaLiqui = SalBruto - DescINSS - DescIRPF;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto <= 2801.56)
            {
                mskbxAliINSS.Text = "11.00%";
                DescINSS = SalBruto * 0.11;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("27.50%");
                DescIRPF = SalBruto * 0.275;
                mskbxDescIRPF.Text = DescIRPF.ToString("N2");
                mskbxSalFam.Text = ("Não se Aplica");
                SalaLiqui = SalBruto - DescINSS - DescIRPF;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }
            else
                if (SalBruto > 2801.56)
            {
                mskbxAliINSS.Text = "308.17 (teto)";
                DescINSS = 308.17;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
                mskbxAliIRPF.Text = ("27.50%");
                DescIRPF = SalBruto * 0.275;
                mskbxDescIRPF.Text = DescIRPF.ToString("N2");
                mskbxSalFam.Text = ("Não se Aplica");
                SalaLiqui = (SalBruto - DescINSS) - DescIRPF;
                mskbxSalLiquido.Text = SalaLiqui.ToString("N2");
            }

        }

        private void MskbxSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out SalBruto) || (SalBruto <= 0))
            {

                MessageBox.Show("Salário inválido");

                mskbxSalBruto.Focus();

            }
        }
    }
}
