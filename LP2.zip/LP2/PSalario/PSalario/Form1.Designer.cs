﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxNome = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnDesconto = new System.Windows.Forms.Button();
            this.mskbxAliINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalFam = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAliINSS = new System.Windows.Forms.Label();
            this.lblAliIRPF = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.lblSalLiqui = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.mskbxFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // mskbxNome
            // 
            this.mskbxNome.Location = new System.Drawing.Point(191, 44);
            this.mskbxNome.Name = "mskbxNome";
            this.mskbxNome.Size = new System.Drawing.Size(411, 20);
            this.mskbxNome.TabIndex = 0;
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(191, 84);
            this.mskbxSalBruto.Mask = "00,999.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(120, 20);
            this.mskbxSalBruto.TabIndex = 1;
            this.mskbxSalBruto.Validated += new System.EventHandler(this.MskbxSalBruto_Validated);
            // 
            // mskbxFilhos
            // 
            this.mskbxFilhos.Location = new System.Drawing.Point(191, 131);
            this.mskbxFilhos.Name = "mskbxFilhos";
            this.mskbxFilhos.Size = new System.Drawing.Size(120, 20);
            this.mskbxFilhos.TabIndex = 2;
            // 
            // btnDesconto
            // 
            this.btnDesconto.Location = new System.Drawing.Point(191, 177);
            this.btnDesconto.Name = "btnDesconto";
            this.btnDesconto.Size = new System.Drawing.Size(120, 23);
            this.btnDesconto.TabIndex = 3;
            this.btnDesconto.Text = "Verifica Descontos";
            this.btnDesconto.UseVisualStyleBackColor = true;
            this.btnDesconto.Click += new System.EventHandler(this.BtnDesconto_Click);
            // 
            // mskbxAliINSS
            // 
            this.mskbxAliINSS.Location = new System.Drawing.Point(191, 230);
            this.mskbxAliINSS.Name = "mskbxAliINSS";
            this.mskbxAliINSS.ReadOnly = true;
            this.mskbxAliINSS.Size = new System.Drawing.Size(120, 20);
            this.mskbxAliINSS.TabIndex = 4;
            // 
            // mskbxAliIRPF
            // 
            this.mskbxAliIRPF.Location = new System.Drawing.Point(191, 267);
            this.mskbxAliIRPF.Name = "mskbxAliIRPF";
            this.mskbxAliIRPF.ReadOnly = true;
            this.mskbxAliIRPF.Size = new System.Drawing.Size(120, 20);
            this.mskbxAliIRPF.TabIndex = 5;
            // 
            // mskbxSalFam
            // 
            this.mskbxSalFam.Location = new System.Drawing.Point(191, 307);
            this.mskbxSalFam.Name = "mskbxSalFam";
            this.mskbxSalFam.ReadOnly = true;
            this.mskbxSalFam.Size = new System.Drawing.Size(120, 20);
            this.mskbxSalFam.TabIndex = 6;
            // 
            // mskbxSalLiquido
            // 
            this.mskbxSalLiquido.Location = new System.Drawing.Point(191, 356);
            this.mskbxSalLiquido.Name = "mskbxSalLiquido";
            this.mskbxSalLiquido.ReadOnly = true;
            this.mskbxSalLiquido.Size = new System.Drawing.Size(120, 20);
            this.mskbxSalLiquido.TabIndex = 7;
            // 
            // mskbxDescINSS
            // 
            this.mskbxDescINSS.Location = new System.Drawing.Point(502, 233);
            this.mskbxDescINSS.Name = "mskbxDescINSS";
            this.mskbxDescINSS.ReadOnly = true;
            this.mskbxDescINSS.Size = new System.Drawing.Size(120, 20);
            this.mskbxDescINSS.TabIndex = 8;
            // 
            // mskbxDescIRPF
            // 
            this.mskbxDescIRPF.Location = new System.Drawing.Point(502, 266);
            this.mskbxDescIRPF.Name = "mskbxDescIRPF";
            this.mskbxDescIRPF.ReadOnly = true;
            this.mskbxDescIRPF.Size = new System.Drawing.Size(120, 20);
            this.mskbxDescIRPF.TabIndex = 9;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(89, 44);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 10;
            this.lblNome.Text = "Nome";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(89, 90);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalBruto.TabIndex = 11;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(89, 137);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblFilhos.TabIndex = 12;
            this.lblFilhos.Text = "Número de Filhos";
            // 
            // lblAliINSS
            // 
            this.lblAliINSS.AutoSize = true;
            this.lblAliINSS.Location = new System.Drawing.Point(89, 236);
            this.lblAliINSS.Name = "lblAliINSS";
            this.lblAliINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAliINSS.TabIndex = 13;
            this.lblAliINSS.Text = "Aliquota INSS";
            // 
            // lblAliIRPF
            // 
            this.lblAliIRPF.AutoSize = true;
            this.lblAliIRPF.Location = new System.Drawing.Point(89, 273);
            this.lblAliIRPF.Name = "lblAliIRPF";
            this.lblAliIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAliIRPF.TabIndex = 14;
            this.lblAliIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Location = new System.Drawing.Point(89, 313);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(74, 13);
            this.lblSalFam.TabIndex = 15;
            this.lblSalFam.Text = "Salário Familia";
            // 
            // lblSalLiqui
            // 
            this.lblSalLiqui.AutoSize = true;
            this.lblSalLiqui.Location = new System.Drawing.Point(89, 362);
            this.lblSalLiqui.Name = "lblSalLiqui";
            this.lblSalLiqui.Size = new System.Drawing.Size(76, 13);
            this.lblSalLiqui.TabIndex = 16;
            this.lblSalLiqui.Text = "Salário Liquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(413, 236);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 17;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(412, 273);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescIRPF.TabIndex = 18;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(413, 352);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 19;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(547, 352);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 20;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 404);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiqui);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblAliIRPF);
            this.Controls.Add(this.lblAliINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.mskbxDescIRPF);
            this.Controls.Add(this.mskbxDescINSS);
            this.Controls.Add(this.mskbxSalLiquido);
            this.Controls.Add(this.mskbxSalFam);
            this.Controls.Add(this.mskbxAliIRPF);
            this.Controls.Add(this.mskbxAliINSS);
            this.Controls.Add(this.btnDesconto);
            this.Controls.Add(this.mskbxFilhos);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.mskbxNome);
            this.Name = "Form1";
            this.Text = "Cálculo Salário";
            ((System.ComponentModel.ISupportInitialize)(this.mskbxFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.NumericUpDown mskbxFilhos;
        private System.Windows.Forms.Button btnDesconto;
        private System.Windows.Forms.MaskedTextBox mskbxAliINSS;
        private System.Windows.Forms.MaskedTextBox mskbxAliIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxSalFam;
        private System.Windows.Forms.MaskedTextBox mskbxSalLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxDescINSS;
        private System.Windows.Forms.MaskedTextBox mskbxDescIRPF;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAliINSS;
        private System.Windows.Forms.Label lblAliIRPF;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label lblSalLiqui;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

