﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn1f2_Click(object sender, EventArgs e)
        {
            
            string abacate = "";
            int N = 0;
            int N1 = 0;
            

            while (true)
            {
                abacate = Interaction.InputBox("Digite os últimos dígitos do teu RA");
                if (int.TryParse(abacate, out N))
                {
                    break;
                    
                }else

                MessageBox.Show("Número Inválido. Tente novamente.");
            }

            if (N == 0)
            {
                N1 = 10;

            }else
            {
                N1 = N;
            }

            string[] aux = new string[N1];

            for (var i = 0; i < N1; i++)
            {
                aux[i] = Interaction.InputBox("Digite os nomes completos das pessoas");
            }

            lstbx1f2.Items.Clear();

            for (var i = 0; i < N1; i++)
            {
                if (!string.IsNullOrEmpty(aux[i]))
                {
                  
                    int count = aux[i].Replace(" ", "").Length;
                    lstbx1f2.Items.Add($"O nome: {aux[i]} tem {count} caracteres (sem espaços em branco).");
                }
            }

        }
    }
}
