﻿namespace Pmatrizes
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1f2 = new System.Windows.Forms.Button();
            this.lstbx1f2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn1f2
            // 
            this.btn1f2.Location = new System.Drawing.Point(126, 124);
            this.btn1f2.Name = "btn1f2";
            this.btn1f2.Size = new System.Drawing.Size(164, 105);
            this.btn1f2.TabIndex = 0;
            this.btn1f2.Text = "Executar";
            this.btn1f2.UseVisualStyleBackColor = true;
            this.btn1f2.Click += new System.EventHandler(this.btn1f2_Click);
            // 
            // lstbx1f2
            // 
            this.lstbx1f2.FormattingEnabled = true;
            this.lstbx1f2.Location = new System.Drawing.Point(460, -1);
            this.lstbx1f2.Name = "lstbx1f2";
            this.lstbx1f2.Size = new System.Drawing.Size(615, 459);
            this.lstbx1f2.TabIndex = 1;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 450);
            this.Controls.Add(this.lstbx1f2);
            this.Controls.Add(this.btn1f2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn1f2;
        private System.Windows.Forms.ListBox lstbx1f2;
    }
}