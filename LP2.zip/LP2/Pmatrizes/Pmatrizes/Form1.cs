﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            string saida = "";
            
            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox($"Digite um número para a posição: {i + 1}");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
                else
                    saida = vetor[i] + "\n" + saida;

            }
            MessageBox.Show(saida);

            /*Array.Reverse(vetor);
            aux = "";
            foreach (int i in vetor)
                aux += i+"\n";
            MessageBox.Show(aux);*/
        }

        private void BtnEx2_Click(object sender, EventArgs e)
        {
            double[,] alunos = new double[20, 3];
            string aux1 = "";
            string resultado = "";
            double soma;
            double media;

            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    aux1 = Interaction.InputBox($"Digite a nota {j + 1} a para o aluno: {i + 1}");
                    if (!double.TryParse(aux1, out alunos[i, j]))
                    {
                        MessageBox.Show("Número Inválido");
                        j--;
                    }
                }
            }


            for (var i = 0; i < 20; i++)
            {
                media = 0;
                soma = 0;

                for (var j = 0; j < 3; j++)
                {
                    soma += alunos[i,j];
                }

                media = soma / 3;
                resultado += $"Aluno {i + 1} média: {media.ToString("N2")}\n";               
            }
                MessageBox.Show(resultado);

        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
            "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string aux = "";

            ArrayList myList = new ArrayList();

            myList.Add("Ana");
            myList.Add("André");
            myList.Add("Débora");
            myList.Add("Fátima");
            myList.Add("João");
            myList.Add("Janete");
            myList.Add("Otávio");
            myList.Add("Marcelo");
            myList.Add("Pedro");   
            myList.Add("Thais");

            myList.RemoveAt(6);

            foreach (var item in myList)
            {
                aux += item.ToString() + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }
    }
}
