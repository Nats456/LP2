﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Text = string.Empty;
            txtLado2.Text = string.Empty;
            txtLado3.Text = string.Empty;
            txtTipo.Text = string.Empty;
            txtLado1.Focus();
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado1.Text, out lado1) || (lado1 <= 0))
            {
                MessageBox.Show("Número inválido");
                txtLado1.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (lado1 > 0 && lado2 > 0 && lado3 > 0 &&
    (lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1))
            {
                if (lado1 == lado2 && lado2 == lado3)
                {
                    txtTipo.Text = "Triângulo Equilátero";
                }
                else if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3)
                {
                    txtTipo.Text = "Triângulo Escaleno";
                }
                else
                {
                    txtTipo.Text = "Triângulo Isósceles";
                }
            }
            else
            {
                MessageBox.Show("Não é um triângulo válido.");
            }
        }

        private void txtTipo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado2.Text, out lado2) || (lado2 <= 0))
            {
                MessageBox.Show("Número inválido");
                txtLado2.Focus();
            }
        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado3.Text, out lado3) || (lado3 <= 0))
            {
                MessageBox.Show("Número inválido");
                txtLado3.Focus();
            }
        }
    }
}