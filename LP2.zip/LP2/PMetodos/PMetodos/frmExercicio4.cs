﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnPrimeiroCarac_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contador = 0;
            while (contador < richTextFrase.Text.Length)
            {
                if (char.IsWhiteSpace(richTextFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show("O 1º caracter em branco esta na posição:"+posicao); 

        }

        private void Btnqtdadecaracnumericos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var i = 0; i < richTextFrase.Text.Length; i++)
            {
                if (char.IsNumber(richTextFrase.Text[i]))
                {
                    contador++;

                }
            }
            MessageBox.Show("Quantidade de números: "+contador);
        }

        private void Btnqtdadecaracalfabeticos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in richTextFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contador++;
                }
            }
            MessageBox.Show($"Número de letras:{contador}");
        }
    }
}
